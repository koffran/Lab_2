using System;

namespace Test_Extensiones
{
    public static class ContarPuntuacion
    {

    public static int ContandoPuntuacion(this string cadena)
    {
      int retorno = 0;
      foreach(char c in cadena)
      {
        if (c == '.' || c == ',' || c == ';')
          retorno++;
      }

      return retorno;
    }
    }
}




/*. Crear un método de extensión para la clase string que cuente la cantidad de signos de puntuación
punto (.), coma (,) y punto y coma (;) dentro de una cadena*/
