using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Extension_72;
using Test_Extensiones;

namespace Test
{
  class Program
  {
    static void Main(string[] args)
    {

      ///EJERCICIO 72
      //long numero;
      //int digitos;

      //Console.WriteLine("Numero 1:");
      //numero = 1;
      //Console.WriteLine($"Cantidad de digitos: {numero.CantidadDeDigitos().ToString()}");

      //Console.WriteLine("Numero 123:");
      //numero = 123;
      //Console.WriteLine($"Cantidad de digitos: {numero.CantidadDeDigitos().ToString()}");

      //Console.WriteLine("Numero 1234:");
      //numero = 1234;
      //Console.WriteLine($"Cantidad de digitos: {numero.CantidadDeDigitos().ToString()}");

      //Console.WriteLine("Numero 1234567890:");
      //numero = 1234567890;
      //Console.WriteLine($"Cantidad de digitos: {numero.CantidadDeDigitos().ToString()}");


      ///EJERCICIO 73

      string cadena = "Hola, me llamo Franco; Como estas? . ";
      Console.WriteLine($"En la cadena: \n{cadena}\nHay {cadena.ContandoPuntuacion()} signos de puntuación");
      Console.ReadKey();
    }
  }
}
