using System;

namespace Extension_72
{
    public static class LongExtension
    {
        public static int CantidadDeDigitos(this long numero)
        {
          int retorno;
          string aux = numero.ToString();
          retorno = aux.Length;
          return retorno;
        }
    }
}


/*Crear un método de extensión para la clase long:
a. Se llamará CantidadDeDigitos y retornará la cantidad de dígitos que forman un número.
b. Utilizar este método para dar informar por pantalla la cantidad de dígitos.
c. Utilizar el formato para que quede tal cual la pantalla planteada:*/
