﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Zarate.Franco._2D.TP3;

namespace Test_Valores_Nulos
{
    [TestClass]
    public class UnitTestNulos
    {
        [TestMethod]
        public void TestMethod1()
        {
            Alumno a = new Alumno(1, "", "", "10", EntidadesAbstractas.Persona.ENacionalidad.Argentino, Universidad.EClases.Legislacion);
            if (a.Dni == 0)
                Assert.Fail();
        }
    }
}
