﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesAbstractas;

namespace Zarate.Franco._2D.TP3
{
    public sealed class Profesor:Universitario
    {
        private Queue<Universidad.EClases> clasesDelDia;
        private static Random random;

        #region Constructores
        static Profesor()
        {
            Profesor.random = new Random(DateTime.Now.Millisecond);
        }

        public Profesor()
        {
            
        }

        public Profesor(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad)
            :base(id,nombre,apellido,dni,nacionalidad)
        {
            this.clasesDelDia = new Queue<Universidad.EClases>();
            this._randomClases();
            this._randomClases();
        }
        #endregion

        #region Sobrecargas
        protected override string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(base.MostrarDatos());
            sb.Append(this.ParticiparEnClase());

            return sb.ToString();
        }

        protected override string ParticiparEnClase()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("CLASES DEL DIA: ");
            foreach (Universidad.EClases c in this.clasesDelDia)
            {
                sb.AppendLine(c.ToString());
            }

            return sb.ToString();
        }

        public override string ToString()
        {
            return this.MostrarDatos();
        }
        #endregion

        #region Metodos
        private void _randomClases()
        {
            switch(Profesor.random.Next(0,4))
            {
                case 0:
                    this.clasesDelDia.Enqueue(Universidad.EClases.Laboratorio);
                    break;
                case 1:
                    this.clasesDelDia.Enqueue(Universidad.EClases.Legislacion);
                    break;
                case 2:
                    this.clasesDelDia.Enqueue(Universidad.EClases.Programacion);
                    break;
                case 3:
                    this.clasesDelDia.Enqueue(Universidad.EClases.SPD);
                    break;
            }
        }
        #endregion

        public static bool operator ==(Profesor i, Universidad.EClases clase)
        {
            foreach(Universidad.EClases c in i.clasesDelDia)
            {
                if (c == clase)
                    return true;
            }
            return false;
        }

        public static bool operator !=(Profesor i, Universidad.EClases clase)
        {
            return !(i == clase);
        }
    }
}
