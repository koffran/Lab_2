﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;

namespace Zarate.Franco._2D.TP3
{
    public class Universidad
    {
        public enum EClases
        {
            Programacion,
            Laboratorio,
            Legislacion,
            SPD
        }

        private List<Alumno> alumnos;
        private List<Profesor> profesores;
        private List<Jornada> jornadas;

        #region Constructores
        public Universidad()
        {
            this.Alumnos = new List<Alumno>();
            this.Instructores = new List<Profesor>();
            this.Jornadas = new List<Jornada>();
        }
        #endregion

        #region Propiedades
        public List<Alumno> Alumnos
        {
            get
            {
                return this.alumnos;
            }
            set
            {
                this.alumnos = value;
            }
        }

        public List<Profesor> Instructores
        {
            get
            {
                return this.profesores;
            }
            set
            {
                this.profesores = value;
            }
        }

        public List<Jornada> Jornadas
        {
            get
            {
                return this.jornadas;
            }
            set
            {
                this.jornadas = value;
            }
        }

        public Jornada this[int i]
        {
            get
            {
                 return this.Jornadas[i];

                
            }
            set
            {
                this.Jornadas[i] = value;
            }
        }
        #endregion

        #region Operadores
        public static bool operator ==(Universidad g,Alumno a)
        {
            foreach(Alumno aux in g.Alumnos)
            {
                if (aux == a)
                    return true;
            }
            return false;
        }

        public static bool operator !=(Universidad g, Alumno a)
        {
            return !(g == a);
        }

        public static bool operator ==(Universidad g, Profesor i)
        {
            foreach (Jornada j in g.Jornadas)
            {
                if (i == j.Clase)
                    return true;
            }
            return false;
        }

        public static bool operator !=(Universidad g, Profesor i)
        {
            return !(g == i);
        }

        /// <summary>
        /// Al agregar una clase a un Universidad se deberá generar y agregar una nueva Jornada indicando la
        ///clase, un Profesor que pueda darla(según su atributo ClasesDelDia) y la lista de alumnos que la
        /// toman(todos los que coincidan en su campo ClaseQueToma).
        /// </summary>
        /// <param name="g"></param>
        /// <param name="clase"></param>
        /// <returns></returns>
        public static Universidad operator +(Universidad g, EClases clase)
        {
            Profesor aux = g == clase;

            Jornada j = new Jornada(clase, aux);

            foreach(Alumno a in g.Alumnos)
            {
                if (a == clase)
                    j +=  a;
            }
            g.Jornadas.Add(j);
            return g;
        }

        public static Universidad operator +(Universidad u, Alumno a)
        {
            if (u != a)
                u.Alumnos.Add(a);
            else
                throw new AlumnoRepetidoException();
            return u;
        }
        
        public static Universidad operator +(Universidad u, Profesor i)
        {
            if (u != i)
                u.Instructores.Add(i);
            return u;
        }

        public static Profesor operator ==(Universidad u, EClases clase)
        {
            Profesor retorno = new Profesor();
            foreach (Profesor i in u.Instructores)
            {
                if (i == clase)
                    retorno = i;
                else
                    throw new SinProfesorException();
            }
            return retorno;

        }

        public static Profesor operator !=(Universidad u, EClases clase)
        {
            Profesor retorno = new Profesor();
            try
            {
                retorno = u == clase;
            }
            catch (SinProfesorException e)
            {
                Console.WriteLine(e.Message);
                retorno = u.Instructores.First();
            }
            return retorno;
        }
        #endregion

        #region Metodos
        private static string MostrarDatos(Universidad uni)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Jornada: ");
            foreach(Jornada j  in uni.Jornadas)
            {
                sb.AppendLine(j.ToString());
            }
            return sb.ToString();
        }


        #endregion

        public override string ToString()
        {
            return Universidad.MostrarDatos(this);
        }

        public static bool Guardar(Universidad uni)
        {
            Xml<string> x = new Xml<string>();
            return x.Guardar("Universidad", uni.ToString());
        }

        public static string Leer()
        {
            Xml<string> x = new Xml<string>();
            string retorno;
            x.Leer("Universidad", out retorno);
            return retorno;
        }
    }
}
/*
 Guardar de clase serializará los datos del Universidad en un XML, incluyendo todos los datos de sus
Profesores, Alumnos y Jornadas.
 Leer de clase retornará un Universidad con todos los datos previamente serializados.*/
