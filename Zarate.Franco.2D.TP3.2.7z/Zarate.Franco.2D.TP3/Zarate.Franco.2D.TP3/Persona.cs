using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;

namespace EntidadesAbstractas
{
    public abstract class Persona
    {
        public enum ENacionalidad
        {
            Argentino,
            Extranjero
        }

        private string nombre;
        private string apellido;
        private ENacionalidad nacionalidad;
        private int dni;

        #region CONSTRUCTORES
        public Persona()
        {

        }

        public Persona(string nombre, string apellido, ENacionalidad nacionalidad)
            :this(nombre,apellido,0,nacionalidad)
        {
            
        }

        public Persona(string nombre, string apellido, int dni, ENacionalidad nacionalidad)
            :this(nombre,apellido, dni.ToString(),nacionalidad)
        {
            
        }

        public Persona(string nombre, string apellido, string dni, ENacionalidad nacionalidad)
        {
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Nacionalidad = nacionalidad;
            this.StringToDNI = dni;

        }
        #endregion

        #region Propiedades
        public string Nombre
        {
            get
            {
                return this.nombre;
            }
            set
            {
                this.nombre = this.ValidarNombreApellido(value);
            }
        }
        public string Apellido
        {
            get
            {
                return this.apellido;
            }
            set
            {
                this.apellido = this.ValidarNombreApellido(value);
            }
        }
        public ENacionalidad Nacionalidad
        {
            get
            {
                return this.nacionalidad;
            }
            set
            {
                this.nacionalidad = value;
            }
        }
        public int Dni
        {
            get
            {
                return this.dni;
            }
            set
            {
                try
                {
                    if (this.ValidarDni(this.Nacionalidad, value) == 1)
                    {
                        this.dni = value;
                    }
                }
                catch (NacionalidadInvalidaException e)
                {
                    throw e;
                }
                catch(FormatException e)
                {
                    throw new DniInvalidoException("Error de formato en DNI",e);
                }
            }
        }
        public string StringToDNI
        {
            set
            {
                this.Dni = int.Parse(value);
            }
        }
        #endregion

        #region METODOS
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat($"NOMBRE COMPLETO: {this.Apellido}, {this.Nombre}\nNacionalidad: {this.Nacionalidad}");
            return sb.ToString();
        }

        private int ValidarDni(ENacionalidad nacionalidad, int dato)
        {
            int retorno = 0;

            if (this.Nacionalidad == ENacionalidad.Argentino && (dato < 90000000 && dato > 0) || this.Nacionalidad == ENacionalidad.Extranjero && (dato >= 90000000 && dato <= 99999999))
                retorno = 1;
            else
                throw new NacionalidadInvalidaException("La nacionalidad no se condice con  el número de DNI");

            return retorno;
        }

        private int ValidarDni(ENacionalidad nacionalidad, string dato)
        {
            int retorno = 0;

            if (this.Nacionalidad == ENacionalidad.Argentino && (int.Parse(dato) < 90000000 && int.Parse(dato) > 0) || this.Nacionalidad == ENacionalidad.Extranjero && (int.Parse(dato) >= 90000000 && int.Parse(dato) <= 99999999))
                retorno = 1;
            else
                throw new NacionalidadInvalidaException("Dni incorrecto");

            return retorno;
        }

        private string ValidarNombreApellido(string dato)
        {
            foreach (char l in dato)
            {
                if (!Char.IsLetter(l))
                    dato = "";
            }

            return dato;
        }
        #endregion
    }
}
