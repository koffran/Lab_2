using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Test;
using Zarate.Franco._2D.TP3;
using Excepciones;
using EntidadesAbstractas;

namespace Exception_Valid
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        [ExpectedException(typeof(NacionalidadInvalidaException))]
        public void Exception_Valid()
    {
      try
      {
        Alumno a = new Alumno(1, "", "", "1", Persona.ENacionalidad.Extranjero, Universidad.EClases.Laboratorio);
      }
      catch (Exception)
      {

        throw;
      }
            
            
        }
    }
}
