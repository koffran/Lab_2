using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace PelotitasForm
{
  public delegate void MiDelegado(UserPelotitas p);

  public partial class UserPelotitas : UserControl
  {
    public Thread hilo;
    public event MiDelegado EventoLlamador;
    public event MiDelegado Perder;

    public UserPelotitas()
    {
      InitializeComponent();
      EventoLlamador += Eliminar;
      Perder += Eliminar;

    }

    private void UserPelotitas_Load(object sender, EventArgs e)
    {

    }

    public void setImage(Bitmap imagen)
    {
      this.pictureBox1.Image = imagen;
      this.pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
    }

    public void Mover(object finPantalla)
    {

      while(this.Left < (int)finPantalla)
      {
        Thread.Sleep(250);
        if(this.InvokeRequired)
        {
          this.BeginInvoke((MethodInvoker)delegate ()
          {
            this.Left += 30;
          }
        );

        }
        else
        {
          this.Left += 30;
        }
        
      }
        this.Perder(this);
    }

    public void Eliminar( UserPelotitas p)
    {
      if (p.hilo.IsAlive )
        p.hilo.Abort();
    }

    private void pictureBox1_Click(object sender, EventArgs e)
    {
      this.EventoLlamador(this);
    }
  }
}
