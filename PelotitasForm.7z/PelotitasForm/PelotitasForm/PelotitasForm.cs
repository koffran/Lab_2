using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace PelotitasForm
{
  public partial class PelotitasForm : Form
  {
    private int puntos;
    public int Puntos
    {
      get
      {
        return this.puntos;
      }
      set
      {
        this.puntos = value;
      }
    }

    public PelotitasForm()
    {
      InitializeComponent();
      this.puntos = 0;
      this.label1.Text = this.Puntos.ToString();
    }

    private void btnIniciar_Click(object sender, EventArgs e)
    {
      UserPelotitas pelotita = new UserPelotitas();
      pelotita.setImage(Properties.Resources.PelotitaImagen);

      Random r = new Random();
      pelotita.Top = r.Next(this.Height - pelotita.Height);

      pelotita.EventoLlamador += SumarPuntos;
      pelotita.Perder += MostrarPuntos;

      Thread hilo = new Thread(new ParameterizedThreadStart(pelotita.Mover));
      pelotita.hilo = hilo;
      
      this.Controls.Add(pelotita);
      hilo.Start(this.Width);
    }

    private void SumarPuntos(UserPelotitas p)
    {
      this.Puntos += 1;
      this.label1.Text = this.Puntos.ToString();
      this.Controls.Remove(p);
    }

    private void MostrarPuntos(UserPelotitas p)
    {
      MessageBox.Show(this.Puntos.ToString());
      this.label1.Text = this.Puntos.ToString();
    }
  }
}
